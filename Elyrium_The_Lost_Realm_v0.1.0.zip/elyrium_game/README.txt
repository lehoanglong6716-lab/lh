ELYRIUM — THE LOST REALM
Version: 0.1.0 · Bản prototype chơi được · Ngôn ngữ: Tiếng Việt

CÁCH MỞ TRÊN MACBOOK
Cách 1 (đơn giản): giải nén thư mục rồi nhấn đúp index.html.
Cách 2: nhấn đúp Mo_game_Mac.command để mở game qua máy chủ cục bộ trên máy (không đưa dữ liệu lên Internet).
Nếu macOS chặn file .command: nhấp phải > Open, hoặc dùng Cách 1.

CÁCH MỞ TRÊN WINDOWS
Giải nén rồi nhấn đúp Mo_game_Windows.bat hoặc index.html.

ĐIỀU KHIỂN
W A S D / phím mũi tên: di chuyển
Shift: chạy nhanh (hao thể lực)
Chuột trái: đánh thường theo hướng trỏ chuột
1: Hỏa cầu (18 mana)
2: Băng chấn (22 mana, gây sát thương quanh bạn và làm chậm)
3 hoặc Space: Lướt ảnh (15 mana)
4: Hồi phục (28 mana)
E: thu thập / kích hoạt cổ thạch / tương tác
C: bàn chế tác
I: túi hành trang
Q: ăn quả mọng
F: uống bình nước (đứng sát bờ hồ rồi nhấn E để uống nước hồ)
H: dùng dược hồi phục
P hoặc Esc: tạm dừng; trong bảng tạm dừng có nút lưu

MỤC TIÊU CHƯƠNG MỞ ĐẦU
1. Thu thập gỗ, đá, thảo dược, tinh thể và quả mọng.
2. Dựng lửa trại, lều và chế tạo vật phẩm sinh tồn.
3. Theo minimap tìm 3 Cổ Thạch Aether và nhấn E để đánh thức chúng.
4. Đánh bại Kẻ Gác Cổng xuất hiện tại phế tích phía Bắc.

CƠ CHẾ ĐÃ CÓ
- Bản đồ cuộn tự do, nhiều vùng địa hình, hồ nước, đường cổ và phế tích.
- Sinh tồn: sinh lực, đói, khát, mana, thể lực.
- Thu thập tài nguyên, chế tạo lửa trại/lều/dược hồi phục/kiếm Aether/bình nước.
- 4 phép nguyên tố/di chuyển/hồi phục, tấn công thường, quái vật, boss và thăng cấp.
- Chu kỳ ngày/đêm, minimap, nhiệm vụ, lưu tự động cục bộ.

LƯU Ý VỀ PHIÊN BẢN
Đây là bản prototype game 2D/2.5D độc lập chạy bằng Canvas và JavaScript, không phải game AAA 3D hoàn chỉnh. Nhân vật, quái, địa hình, hiệu ứng và giao diện trong gameplay được dựng bằng hình vẽ Canvas; ảnh concept-art được tạo riêng dùng cho màn hình mở đầu, chân dung HUD và bàn phép.

Gói tải được giữ nhỏ để mở nhanh và phù hợp với MacBook Intel 2019 / RAM 8 GB. Không thêm dữ liệu rỗng chỉ để làm gói nặng 2–10 GB. Một game thương mại 2–10 GB cần đội ngũ, engine 3D, mô hình/hoạt ảnh chất lượng cao, âm thanh, kiểm thử và tối ưu riêng; bản này là nền móng chơi được để phát triển tiếp.
